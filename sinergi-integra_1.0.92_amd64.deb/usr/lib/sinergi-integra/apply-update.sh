#!/bin/sh
#
# Applies the engine update that the console requested. Runs as root, started by
# sinergi-integra-updater.path when the console writes updates/request.json.
#
# There is no signature: an administrator chose this package and re-entered
# their password. So this script cannot tell a SINERGI package from somebody
# else's, and does the next best things — it trusts nothing the engine account
# wrote (the request is parsed by the installed engine binary, which accepts only
# a plain file name; the package is copied somewhere only root can reach and
# checked there), it never writes into the engine's directory, it backs up before
# it touches anything, and it puts the old version back if the new one does not
# come up.
#
# Progress goes to /run/sinergi-integra-updater/status.json, which the console
# reads. The record of what was done goes to history.jsonl.

set -eu

# Overridable so the script can be tested without a real server. systemd sets
# none of them, and a root-run unit's environment is not the engine's to choose.
UPDATES="${SINERGI_UPDATES_DIR:-/var/lib/sinergi-integra/updates}"
WORKROOT="${SINERGI_UPDATER_DIR:-/var/lib/sinergi-integra-updater}"
RUN="${SINERGI_UPDATER_RUN_DIR:-/run/sinergi-integra-updater}"
BIN="${SINERGI_INTEGRA_BIN:-/usr/bin/sinergi-integra}"
CONF="${SINERGI_INTEGRA_CONF:-/etc/sinergi-integra/engine.toml}"
ENVFILE="${SINERGI_INTEGRA_ENV:-/etc/sinergi-integra/engine.env}"
STATE_DIR="${SINERGI_STATE_DIR:-/var/lib/sinergi-integra}"
LOCK="${SINERGI_UPDATER_LOCK:-/run/sinergi-integra-updater.lock}"
HEALTH_TIMEOUT="${SINERGI_HEALTH_TIMEOUT:-90}"
MAX_BYTES=209715200
KEEP=3

# One update at a time. A second request that arrives while one runs is left
# alone; the console refuses to queue one anyway.
exec 9>"$LOCK"
flock -n 9 || exit 0

[ -e "$UPDATES/request.json" ] || [ -L "$UPDATES/request.json" ] || exit 0

mkdir -p "$RUN" "$WORKROOT/incoming" "$WORKROOT/previous" "$WORKROOT/backups"
chmod 0755 "$RUN" "$WORKROOT"
chmod 0700 "$WORKROOT/incoming" "$WORKROOT/previous" "$WORKROOT/backups"
touch "$WORKROOT/history.jsonl"; chmod 0644 "$WORKROOT/history.jsonl"

FROM=$(dpkg-query -W -f='${Version}' sinergi-integra 2>/dev/null || echo '?')
TO='?'
STEP=starting
ROLLBACK=''
LOG=''
BY='?'
SHA=''

# --------------------------------------------------------------------- status

# JSON by hand: nothing here may assume a JSON tool is installed. Everything that
# goes in is passed through `clean`, which drops the characters that would break
# the document.
clean() { printf '%s' "$1" | tr -d '"\\\r' | tr '\n\t' '  ' | cut -c1-400; }

# write_status STATE MESSAGE — to /run, root's, which the engine only reads.
write_status() {
    tail_text=$(printf '%s' "$LOG" | tail -n 8 | sed 's/\\/ /g; s/"/ /g' | awk 'BEGIN{ORS="\\n"}{print}')
    tmp="$RUN/status.json.partial"
    printf '{"step":"%s","state":"%s","message":"%s","from_version":"%s","to_version":"%s","rollback_version":"%s","log_tail":"%s","updated_at":%s}\n' \
        "$(clean "$STEP")" "$1" "$(clean "$2")" "$(clean "$FROM")" "$(clean "$TO")" \
        "$(clean "$ROLLBACK")" "$tail_text" "$(date +%s)" > "$tmp"
    chmod 0644 "$tmp"
    mv "$tmp" "$RUN/status.json"
}

# One line per update, success or not: who, when, from -> to, the file's hash.
write_history() {
    printf '{"at":%s,"by":"%s","from":"%s","to":"%s","sha256":"%s","result":"%s"}\n' \
        "$(date +%s)" "$(clean "$BY")" "$(clean "$FROM")" "$(clean "$TO")" "$(clean "$SHA")" "$1" >> "$WORKROOT/history.jsonl"
}

step() { STEP="$1"; printf 'sinergi-integra updater: %s\n' "$1"; write_status running "$2"; }

failed() {
    printf 'sinergi-integra updater: FAILED at %s: %s\n' "$STEP" "$1" >&2
    write_status failed "$1"
    write_history failed
    exit 1
}

# Whatever happens, never leave the console believing an update is still running.
trap 'rc=$?; if [ "$rc" -ne 0 ] && ! grep -q "\"state\":\"failed\"" "$RUN/status.json" 2>/dev/null; then write_status failed "the updater stopped unexpectedly (exit $rc)"; write_history failed; fi' EXIT

# ------------------------------------------------------------------ the request

STEP=request
write_status running "Reading the request"

# Taken out of the engine's directory first, and deleted straight away so the
# path unit does not fire again the moment this run ends. A symlink is refused:
# the engine account could point it at anything root can read.
if [ -L "$UPDATES/request.json" ] || [ ! -f "$UPDATES/request.json" ]; then
    rm -f "$UPDATES/request.json"
    failed "the request was not a plain file"
fi
cp -P "$UPDATES/request.json" "$WORKROOT/incoming/request.json"
rm -f "$UPDATES/request.json"
[ -f "$WORKROOT/incoming/request.json" ] && [ ! -L "$WORKROOT/incoming/request.json" ] || failed "the request was not a plain file"

REQ=$("$BIN" update-request "$WORKROOT/incoming/request.json" 2>&1) || failed "the request was refused: $(printf '%s' "$REQ" | tail -n 1)"
field() { printf '%s\n' "$REQ" | sed -n "s/^$1=//p"; }
FILE=$(field file); SHA=$(field sha256); BY=$(field requested_by); WANT_ROLLBACK=$(field rollback)

# The version inside a package file.
deb_version() { dpkg-deb -f "$1" Version 2>/dev/null || true; }

# A package kept from an earlier update, newest first, other than the version
# given.
previous_other_than() {
    for candidate in $(ls -1t "$WORKROOT/previous"/*.deb 2>/dev/null); do
        v=$(deb_version "$candidate")
        [ -n "$v" ] && [ "$v" != "$1" ] && { printf '%s\n' "$candidate"; return 0; }
    done
    return 1
}

# The package kept for exactly this version, for going back to it.
previous_for() {
    for candidate in "$WORKROOT/previous"/*.deb; do
        [ -f "$candidate" ] || continue
        [ "$(deb_version "$candidate")" = "$1" ] && { printf '%s\n' "$candidate"; return 0; }
    done
    return 1
}

# The version a manual rollback would go back to, or nothing.
rollback_version() {
    found=$(previous_other_than "$1" || true)
    [ -n "$found" ] && deb_version "$found" || true
}

ROLLBACK=$(rollback_version "$FROM")

# ---------------------------------------------------------------------- the copy

step copy "Copying the package"
WORK="$WORKROOT/incoming/work"
rm -rf "$WORK"; mkdir -p "$WORK"; chmod 0700 "$WORK"

if [ "$WANT_ROLLBACK" = true ]; then
    SRC=$(previous_other_than "$FROM") || failed "there is no earlier version kept to go back to"
    cp "$SRC" "$WORK/update.deb"
else
    STAGED="$UPDATES/staging/$FILE"
    # Neither the directory nor the file may be a link: both are the engine's,
    # and a link would make root read whatever it points at.
    [ ! -L "$UPDATES" ] && [ ! -L "$UPDATES/staging" ] && [ -f "$STAGED" ] && [ ! -L "$STAGED" ] || failed "the staged package is missing, or is not a plain file"
    [ "$(wc -c < "$STAGED")" -le "$MAX_BYTES" ] || failed "the package is over the 200 MB limit"
    # `-P` copies a link as a link rather than following it; the copy is checked
    # again, because the check above and the copy are not one instant.
    cp -P "$STAGED" "$WORK/update.deb"
fi
[ -f "$WORK/update.deb" ] && [ ! -L "$WORK/update.deb" ] || failed "the package was not a plain file"
chmod 0600 "$WORK/update.deb"
[ "$(wc -c < "$WORK/update.deb")" -le "$MAX_BYTES" ] || failed "the package is over the 200 MB limit"

# ------------------------------------------------------------------- validation

step validate "Checking the package"

# Everything below is on the copy, and none of it relies on what the engine
# showed the administrator.
[ "$(head -c 8 "$WORK/update.deb")" = '!<arch>' ] || failed "that is not a .deb file"
[ "$(dpkg-deb -f "$WORK/update.deb" Package 2>/dev/null)" = "sinergi-integra" ] || failed "the package is not sinergi-integra"
[ "$(dpkg-deb -f "$WORK/update.deb" Architecture 2>/dev/null)" = "$(dpkg --print-architecture)" ] || failed "the package is for a different processor"
TO=$(deb_version "$WORK/update.deb")
[ -n "$TO" ] || failed "the package did not name a version"
SHA=$(sha256sum "$WORK/update.deb" | cut -d' ' -f1)

# Newer only. Going back is the rollback request's job, which names a package
# this updater kept itself.
if [ "$WANT_ROLLBACK" != true ] && [ "$FROM" != '?' ] && ! dpkg --compare-versions "$TO" gt "$FROM"; then
    failed "v$TO is not newer than the installed v$FROM"
fi

# Dependencies, without installing anything: dpkg stops on an unmet one. This
# matters on a machine with no network, where nothing would fetch it afterwards.
DRY=$(DEBIAN_FRONTEND=noninteractive dpkg --dry-run -i "$WORK/update.deb" 2>&1) || { LOG="$DRY"; failed "dependencies are not met"; }

# What a failure from here on can go back to. Absent on a server whose first
# update this is; then there is no automatic rollback, and the status says so.
BACK=$(previous_for "$FROM" || true)

# ----------------------------------------------------------------------- backup

step backup "Backing up the configuration and the database"
STAMP=$(date +%Y%m%d-%H%M%S)
BK="$WORKROOT/backups/$STAMP"
mkdir -p "$BK"; chmod 0700 "$BK"

[ -d /etc/sinergi-integra ] && tar -C / -czf "$BK/config.tar.gz" etc/sinergi-integra 2>/dev/null || true
tar -C / --exclude="${STATE_DIR#/}/updates" -czf "$BK/state.tar.gz" "${STATE_DIR#/}" 2>/dev/null || true

# The URL the engine itself uses: the one the wizard saved wins, then the one in
# engine.env. A file the engine account wrote is read only if it is a plain file.
DB_URL=''
if [ -f "$STATE_DIR/database.url" ] && [ ! -L "$STATE_DIR/database.url" ]; then
    DB_URL=$(head -n 1 "$STATE_DIR/database.url" | tr -d '\r')
fi
if [ -z "$DB_URL" ] && [ -f "$ENVFILE" ]; then
    DB_URL=$(sed -n 's/^SINERGI_INTEGRA_DATABASE_URL=//p' "$ENVFILE" | tail -n 1 | sed 's/^["'"'"']//; s/["'"'"']$//')
fi

HAVE_DUMP=no
if [ -n "$DB_URL" ]; then
    command -v pg_dump >/dev/null 2>&1 || failed "pg_dump is not installed, so the database cannot be backed up and nothing was changed"
    pg_dump -Fc "$DB_URL" > "$BK/database.dump" || failed "the database backup failed, so nothing was changed"
    HAVE_DUMP=yes
fi
# Newest few only.
ls -1dt "$WORKROOT/backups"/*/ 2>/dev/null | tail -n +$((KEEP + 1)) | while read -r old; do rm -rf "$old"; done

# ---------------------------------------------------------------------- install

health() {
    # $1 the version to wait for, asked of the address the engine listens on.
    addr=$(sed -n 's/^ *bind *= *"\(.*\)".*/\1/p' "$CONF" 2>/dev/null | head -n 1)
    addr="${addr:-127.0.0.1:8099}"
    # A wildcard bind is reachable on the loopback.
    case "$addr" in 0.0.0.0:*) addr="127.0.0.1:${addr#0.0.0.0:}";; "[::]":*|"[::]:"*) addr="127.0.0.1:${addr##*:}";; esac
    waited=0
    while [ "$waited" -lt "$HEALTH_TIMEOUT" ]; do
        if command -v curl >/dev/null 2>&1; then
            body=$(curl -fsS --max-time 3 "http://$addr/api/version" 2>/dev/null || true)
        else
            body=$(wget -qO- -T 3 "http://$addr/api/version" 2>/dev/null || true)
        fi
        [ "$(printf '%s' "$body" | sed -n 's/.*"version" *: *"\([^"]*\)".*/\1/p')" = "$1" ] && return 0
        sleep 2; waited=$((waited + 2))
    done
    return 1
}

# Puts the old version back, and the database as it was: the new version runs
# forward-only migrations when it starts, so the old program cannot be trusted
# with the new schema. Returns non-zero if it could not.
go_back() {
    [ -n "$BACK" ] || return 1
    step rollback "Putting v$FROM back"
    DEBIAN_FRONTEND=noninteractive dpkg -i "$BACK" >/dev/null 2>&1 || return 1
    if [ "$HAVE_DUMP" = yes ]; then
        pg_restore --clean --if-exists -d "$DB_URL" "$BK/database.dump" >/dev/null 2>&1 || true
        systemctl try-restart sinergi-integra.service >/dev/null 2>&1 || true
    fi
    health "$FROM"
}

step install "Installing v$TO"
if OUT=$(DEBIAN_FRONTEND=noninteractive dpkg -i "$WORK/update.deb" 2>&1); then
    step health "Waiting for v$TO to start"
    if health "$TO"; then
        # The package that is running becomes the one a later rollback can use.
        cp "$WORK/update.deb" "$WORKROOT/previous/sinergi-integra_${TO}.deb"
        ls -1t "$WORKROOT/previous"/*.deb 2>/dev/null | tail -n +$((KEEP + 1)) | while read -r old; do rm -f "$old"; done
        ROLLBACK=$(rollback_version "$TO")
        # The engine's staging file is the engine's to remove; the console clears
        # it when it next sees the update has finished.
        rm -rf "$WORK"
        STEP=done
        write_status success "Updated to v$TO"
        write_history success
        exit 0
    fi
    LOG=$(journalctl -u sinergi-integra.service -n 8 --no-pager 2>/dev/null || true)
    CAUSE="v$TO did not start within ${HEALTH_TIMEOUT}s"
else
    LOG="$OUT"
    CAUSE="dpkg failed to install v$TO"
fi

# Something went wrong after the package was touched.
if [ "$WANT_ROLLBACK" = true ]; then
    failed "$CAUSE"
fi
if go_back; then
    STEP=rollback
    failed "$CAUSE. v$FROM was put back and is running."
fi
failed "$CAUSE. There was no earlier package kept to go back to (a first update has none); reinstall v$FROM by hand."
