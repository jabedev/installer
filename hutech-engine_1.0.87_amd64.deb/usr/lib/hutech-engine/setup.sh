#!/bin/sh
#
# What both packages do once their files are on disk.
#
# The .deb calls this from its postinst and the tarball calls it from
# install.sh, so there is one copy of the awkward parts — creating a system
# account, writing a first configuration without ever overwriting one, and
# getting a PostgreSQL the engine can reach. Two implementations of that would
# be two sets of bugs, and only one of them would get tested.
#
# POSIX sh on purpose: a Debian postinst runs under dash, and bashisms here
# would work everywhere except the place they are needed.
#
# Every step is idempotent. This script runs again on every upgrade, and a
# second run must be a no-op rather than a second account or a rotated password.

set -eu

USER_NAME=hutech-engine
GROUP_NAME=hutech-engine
CONF_DIR=/etc/hutech-engine
CONF="$CONF_DIR/engine.toml"
ENV_FILE="$CONF_DIR/engine.env"
STATE_DIR=/var/lib/hutech-engine
EXAMPLE=/usr/share/hutech-engine/engine.example.toml
BIN=/usr/bin/hutech-engine
# This script's own path, for the waiter below, which runs it again later.
SELF=$(readlink -f "$0" 2>/dev/null || printf '%s' "$0")

DB_NAME=hutech_engine
DB_USER=hutech_engine
DB_URL_VAR=HUTECH_ENGINE_DATABASE_URL

# The oldest PostgreSQL the engine's migrations are written for, as
# server_version_num, and the one installed beside anything older.
PG_MIN=140000
PG_BESIDE=16
# The cluster everything below talks to. Found by `pick_cluster`, because a
# machine that had an old PostgreSQL ends up with two.
PG_PORT=5432
PG_VERSION_NUM=0

say() { printf '%s\n' "$*"; }
warn() { printf 'hutech-engine: %s\n' "$*" >&2; }
have() { command -v "$1" >/dev/null 2>&1; }

# ---------------------------------------------------------------------------
# The service account
# ---------------------------------------------------------------------------

ensure_user() {
    if ! getent group "$GROUP_NAME" >/dev/null 2>&1; then
        groupadd --system "$GROUP_NAME"
    fi

    if getent passwd "$USER_NAME" >/dev/null 2>&1; then
        return 0
    fi

    # `nologin` is in different places on different distributions, and passing
    # one that does not exist makes some `useradd` builds refuse outright.
    nologin=/usr/sbin/nologin
    [ -x "$nologin" ] || nologin=/sbin/nologin
    [ -x "$nologin" ] || nologin=/bin/false

    useradd --system \
        --gid "$GROUP_NAME" \
        --home-dir "$STATE_DIR" \
        --no-create-home \
        --shell "$nologin" \
        --comment "HuTech Engine" \
        "$USER_NAME"

    say "created the $USER_NAME system account"
}

# ---------------------------------------------------------------------------
# Directories
# ---------------------------------------------------------------------------

ensure_dirs() {
    # systemd's StateDirectory= creates this too, but the database step below
    # runs before the service has ever started.
    mkdir -p "$CONF_DIR" "$STATE_DIR"
    chown root:"$GROUP_NAME" "$CONF_DIR"
    chmod 0750 "$CONF_DIR"
    chown "$USER_NAME":"$GROUP_NAME" "$STATE_DIR"
    chmod 0750 "$STATE_DIR"
    # Where the console stages an update and asks for it, and where the root
    # updater keeps what it needs to roll back. The first is the engine's; the
    # second is root's alone.
    mkdir -p "$STATE_DIR/updates/staging" /var/lib/hutech-engine-updater
    chown "$USER_NAME":"$GROUP_NAME" "$STATE_DIR/updates" "$STATE_DIR/updates/staging"
    chmod 0750 "$STATE_DIR/updates" "$STATE_DIR/updates/staging"
    chmod 0755 /var/lib/hutech-engine-updater
}

# ---------------------------------------------------------------------------
# The first configuration
# ---------------------------------------------------------------------------

# Written once and never touched again.
#
# This is the same rule the engine already follows for a config it creates
# itself, and it is the one an installer is most tempted to break: a package
# that lays its configuration down on every upgrade takes the customer's RMM
# credentials with it. That is why engine.toml is deliberately *not* a dpkg
# conffile — dpkg would then prompt about it on every upgrade, having watched us
# modify a file it thinks it owns.
#
# Deliberately minimal, and deliberately not engine.example.toml. The example
# carries two `[[connectors]]` blocks full of `env:` references; the engine
# resolves those at startup and refuses to start when the variables are unset,
# so shipping it as a live configuration would install a service that cannot
# boot. The example goes to /usr/share instead, to be read and copied from.
ensure_config() {
    if [ -e "$CONF" ]; then
        say "keeping the existing $CONF"
        return 0
    fi

    cat > "$CONF" <<EOF
# HuTech Engine — site configuration.
#
# Written by the installer on first install, and never touched again — not by an
# upgrade, and not by the engine. It is yours to edit.
#
# Every option, with what it does and why: $EXAMPLE

# Paste the key from your HuTech dashboard here, or finish setup in the console
# below, which writes it to $STATE_DIR/licence.key instead.
licence_key = ""

# Loopback on purpose: this process holds the credentials for your RMM. Before
# changing this to 0.0.0.0:8099, set [auth] password_hash — the engine refuses to
# start when it is reachable from the network and open to anyone.
bind = "127.0.0.1:8099"

# Seconds between polls of each connector.
poll_interval_secs = 300

# Add one [[connectors]] block per system to monitor. See the example above;
# secrets belong in $ENV_FILE as env:VARIABLE references rather than here.
EOF

    chown root:"$GROUP_NAME" "$CONF"
    chmod 0640 "$CONF"
    say "wrote $CONF"
}

ensure_env_file() {
    if [ ! -e "$ENV_FILE" ]; then
        cat > "$ENV_FILE" <<EOF
# Secrets for the env:VARIABLE references in engine.toml.
#
# Read by systemd and handed to the engine as environment variables, so they
# never appear in engine.toml and never reach a configuration-management diff.
#
#   VSAX_TOKEN_ID=...
#   VSAX_TOKEN_SECRET=...
#   VSA95_PAT=...
EOF
    fi

    ensure_secret_key

    # Root writes it, the engine's account reads it, nobody else sees it.
    chown root:"$GROUP_NAME" "$ENV_FILE"
    chmod 0640 "$ENV_FILE"
}

# The key that connector credentials are encrypted with.
#
# Generated here, once, and never regenerated: a new key does not re-encrypt
# what the old one sealed, it makes it unreadable. So an upgrade that quietly
# minted a fresh key would silently break every connector an operator had added
# from the console, and the only fix would be typing every credential again.
#
# Generated at install rather than on demand because the alternative is an
# operator reaching the connectors page, being told to run a command over SSH,
# and going to find someone with root. The key is worth nothing on its own --
# it protects rows in a database that does not contain it.
ensure_secret_key() {
    if grep -q '^HUTECH_ENGINE_SECRET_KEY=' "$ENV_FILE" 2>/dev/null; then
        return 0
    fi

    # `generate-key` prints the key on stdout and its instructions on stderr,
    # which is what makes this append safe.
    key=$("$BIN" generate-key 2>/dev/null) || {
        warn "could not generate a credential key; connectors can still be added to engine.toml"
        return 0
    }

    printf 'HUTECH_ENGINE_SECRET_KEY=%s\n' "$key" >> "$ENV_FILE"

    # Point engine.toml at it. Without this the key exists and nothing reads it,
    # and the connectors page would still say there is no key configured -- the
    # most confusing possible state, because the operator can see the variable.
    if ! grep -q '^\[secrets\]' "$CONF" 2>/dev/null; then
        cat >> "$CONF" <<EOF

# Added by the installer. The key itself is in $ENV_FILE, deliberately not
# here: it protects credentials stored in the database, so it must not live
# anywhere a database backup would carry it.
[secrets]
key = "env:HUTECH_ENGINE_SECRET_KEY"
EOF
    fi

    say "generated a key for encrypting connector credentials"
}

# ---------------------------------------------------------------------------
# PostgreSQL
# ---------------------------------------------------------------------------
#
# Nothing here is allowed to fail the install. The engine runs perfectly well
# without a database — one password, live data, no history and no audit trail —
# so a site whose package manager we do not recognise, or whose PostgreSQL will
# not start, gets a working engine and a message saying what it is missing. The
# alternative is a failed install on a box where monitoring is the thing that
# was wanted.

as_postgres() {
    # Reads SQL on stdin. `-s /bin/sh` because the postgres account's shell is
    # often nologin, and `su` honours it.
    su -s /bin/sh postgres -c "psql -p $PG_PORT -v ON_ERROR_STOP=1 -tAX"
}

# server_version_num of whatever answers on port $1, or nothing.
version_on() {
    printf 'SHOW server_version_num' | su -s /bin/sh postgres -c "psql -p $1 -tAX" 2>/dev/null \
        | tr -d '[:space:]'
}

# Finds the newest PostgreSQL on this machine and points PG_PORT at it.
#
# Newest rather than first, because a machine whose PostgreSQL was too old has
# a second one beside it after this script has run, on the next port up — and
# every later run, an upgrade included, has to find that one again rather than
# the old one on 5432.
pick_cluster() {
    have psql || return 1
    getent passwd postgres >/dev/null 2>&1 || return 1

    best=
    best_num=0
    for port in 5432 5433 5434 5435 5436; do
        num=$(version_on "$port")
        case "$num" in
            ''|*[!0-9]*) continue ;;
        esac
        if [ "$num" -gt "$best_num" ]; then
            best=$port
            best_num=$num
        fi
    done

    [ -n "$best" ] || return 1
    PG_PORT=$best
    PG_VERSION_NUM=$best_num
}

postgres_ready() {
    pick_cluster
}

too_old() {
    [ "$PG_VERSION_NUM" -lt "$PG_MIN" ]
}

# apt, dpkg, dnf or yum still running — another install, unattended-upgrades,
# or the very apt run that installed this package.
package_manager_busy() {
    have pgrep || return 1
    pgrep -x 'apt|apt-get|dpkg|dnf|yum|unattended-upgr' >/dev/null 2>&1
}

# Up to ten minutes for the package manager to let go of its lock.
wait_for_package_manager() {
    tries=0
    while package_manager_busy; do
        tries=$((tries + 1))
        [ "$tries" -ge 120 ] && return 1
        sleep 5
    done
}

install_postgres() {
    if have apt-get; then
        say "installing PostgreSQL with apt-get"
        DEBIAN_FRONTEND=noninteractive apt-get install -y postgresql >/dev/null
    elif have dnf; then
        # Red Hat 9's default stream is still 13, which is too old. Its own
        # AppStream carries 16 as a module stream, so a fresh machine gets a
        # new enough PostgreSQL from the distribution itself — no third-party
        # repository. Harmless where there are no modules (Red Hat 10, Fedora).
        say "installing PostgreSQL with dnf"
        dnf module enable -y "postgresql:$PG_BESIDE" >/dev/null 2>&1 || true
        dnf install -y postgresql-server >/dev/null
        [ -d /var/lib/pgsql/data/base ] || postgresql-setup --initdb >/dev/null 2>&1 || true
    elif have yum; then
        say "installing PostgreSQL with yum"
        yum install -y postgresql-server >/dev/null
        [ -d /var/lib/pgsql/data/base ] || postgresql-setup --initdb >/dev/null 2>&1 || true
    elif have zypper; then
        say "installing PostgreSQL with zypper"
        zypper --non-interactive install postgresql-server >/dev/null
    else
        return 1
    fi

    systemctl enable --now postgresql >/dev/null 2>&1 || true
    start_debian_clusters
}

# Debian starts a new cluster through its init script, which a machine without
# systemd — a container, a chroot — may not run. Starting one that is already
# up is a no-op, so this is safe everywhere.
start_debian_clusters() {
    have pg_lsclusters && have pg_ctlcluster || return 0
    pg_lsclusters -h 2>/dev/null | while read -r version cluster _; do
        pg_ctlcluster "$version" "$cluster" start >/dev/null 2>&1 || true
    done
}

# A free port for a second cluster: the first from 5433 nothing answers on.
free_port() {
    for port in 5433 5434 5435 5436; do
        if [ -z "$(version_on "$port")" ]; then
            printf '%s' "$port"
            return 0
        fi
    done
    return 1
}

# PostgreSQL $PG_BESIDE beside an older one, never instead of it.
#
# The old one may be serving something else on this machine, and upgrading a
# cluster in place is a decision about somebody else's data. So the new one is
# its own cluster on its own port, from the PostgreSQL project's repository
# (the distribution's has nothing newer, which is why we are here), and the old
# one is not stopped, upgraded or reconfigured.
install_postgres_beside() {
    if ! wait_for_package_manager; then
        warn "the package manager stayed busy for ten minutes, so PostgreSQL $PG_BESIDE was not installed"
        return 1
    fi

    if have apt-get; then
        # shellcheck disable=SC1091
        codename=$(. /etc/os-release 2>/dev/null && printf '%s' "${VERSION_CODENAME:-}")
        [ -n "$codename" ] || return 1
        keyring=/usr/share/postgresql-common/pgdg/apt.postgresql.org.asc

        say "adding the PostgreSQL project's apt repository for $codename"
        DEBIAN_FRONTEND=noninteractive apt-get install -y ca-certificates curl >/dev/null 2>&1 || return 1
        mkdir -p "$(dirname "$keyring")"
        curl -fsSL -o "$keyring" https://www.postgresql.org/media/keys/ACCC4CF8.asc || return 1
        printf 'deb [signed-by=%s] https://apt.postgresql.org/pub/repos/apt %s-pgdg main\n' \
            "$keyring" "$codename" > /etc/apt/sources.list.d/pgdg.list
        apt-get update >/dev/null 2>&1 || return 1

        say "installing PostgreSQL $PG_BESIDE beside the existing one"
        DEBIAN_FRONTEND=noninteractive apt-get install -y "postgresql-$PG_BESIDE" >/dev/null || return 1

        # Debian creates no cluster for a new major when an older one exists —
        # on purpose, so that its admin can pg_upgradecluster into it. This is
        # not that, so the cluster is made here, on a port of its own.
        if ! pg_lsclusters -h 2>/dev/null | grep -q "^$PG_BESIDE "; then
            port=$(free_port) || return 1
            pg_createcluster "$PG_BESIDE" main --port="$port" >/dev/null || return 1
        fi
        systemctl enable --now "postgresql@$PG_BESIDE-main" >/dev/null 2>&1 || true
        start_debian_clusters
    elif have dnf || have yum; then
        manager=dnf
        have dnf || manager=yum
        rhel=$(rpm -E '%{rhel}' 2>/dev/null)
        case "$rhel" in
            ''|*[!0-9]*) return 1 ;;
        esac

        say "adding the PostgreSQL project's repository for EL $rhel"
        "$manager" install -y \
            "https://download.postgresql.org/pub/repos/yum/reporpms/EL-$rhel-$(uname -m)/pgdg-redhat-repo-latest.noarch.rpm" \
            >/dev/null 2>&1 || true

        say "installing PostgreSQL $PG_BESIDE beside the existing one"
        "$manager" install -y "postgresql$PG_BESIDE-server" >/dev/null || return 1

        data=/var/lib/pgsql/$PG_BESIDE/data
        [ -d "$data/base" ] || "/usr/pgsql-$PG_BESIDE/bin/postgresql-$PG_BESIDE-setup" initdb >/dev/null || return 1

        # Red Hat's packaging does not move a second cluster off 5432, where the
        # old one already listens, so this does.
        port=$(free_port) || return 1
        sed -i "s/^#\{0,1\}port = [0-9]*/port = $port/" "$data/postgresql.conf"
        systemctl enable --now "postgresql-$PG_BESIDE" >/dev/null 2>&1 || return 1
    else
        return 1
    fi
}
# A password made only of hex digits, which is not laziness.
#
# It goes into a URL. Anything that could contain `@`, `:`, `/` or `#` would
# have to be percent-encoded correctly by this script, and a connection string
# that is subtly wrong fails at the engine with an error about the *host*.
generate_password() {
    if have openssl; then
        openssl rand -hex 24
    else
        od -An -tx1 -N24 /dev/urandom | tr -d ' \n'
    fi
}

# Can the engine authenticate the way it is about to be told to?
#
# Asked instead of assumed, because the answer differs by distribution and the
# failure is silent: Debian's pg_hba.conf lets a loopback password connection
# through, and Red Hat's answers `ident` to the same request. Creating the role,
# writing the URL and announcing success produced an engine that could not
# connect to the database the installer had just made for it.
engine_can_connect() {
    PGPASSWORD="$1" psql -h 127.0.0.1 -p "$2" -U "$DB_USER" -d "$DB_NAME" \
        -tAc 'SELECT 1' >/dev/null 2>&1
}

# Adds one loopback rule for this database and this role, and nothing else.
#
# `md5` rather than `scram-sha-256` on purpose, and it is not the weaker choice
# it looks like: where the stored password is a SCRAM verifier — PostgreSQL 14
# and later, which is everything we ask for — the `md5` method negotiates SCRAM
# by itself. Naming `scram-sha-256` here instead would lock out the PostgreSQL
# 13 that `dnf install postgresql-server` still puts on a Red Hat 9 box, whose
# password_encryption is md5.
#
# Prepended, not appended: pg_hba.conf is first-match-wins, and the rule this
# exists to get around is already in the file above wherever an append lands.
allow_password_auth() {
    hba=$(printf 'SHOW hba_file' | as_postgres 2>/dev/null | tr -d '[:space:]')
    [ -n "$hba" ] && [ -f "$hba" ] || return 1
    grep -q 'hutech-engine installer' "$hba" && return 1

    tmp=$(mktemp)
    {
        echo "# Added by the hutech-engine installer. The engine connects over"
        echo "# loopback with a password; this has to sit above the distribution's"
        echo "# own rule, because the first match wins."
        printf 'host    %s    %s    127.0.0.1/32    md5\n' "$DB_NAME" "$DB_USER"
        printf 'host    %s    %s    ::1/128         md5\n' "$DB_NAME" "$DB_USER"
        echo
        cat "$hba"
    } > "$tmp"

    # Copied *into* the original rather than moved over it, so the file keeps
    # the ownership and mode PostgreSQL insists on. A `mv` here leaves it owned
    # by root and PostgreSQL then refuses to start.
    cat "$tmp" > "$hba"
    rm -f "$tmp"

    printf 'SELECT pg_reload_conf()' | as_postgres >/dev/null 2>&1
    say "allowed the engine to authenticate on loopback"
}

# PostgreSQL 14 is what the engine's migrations are written against.
# Said when PostgreSQL $PG_BESIDE could not be put beside an old one — no
# network to the PostgreSQL project's repository, most often.
warn_if_too_old() {
    version=$(printf 'SHOW server_version' | as_postgres 2>/dev/null | tr -d '[:space:]')
    warn "this machine's PostgreSQL is $version, the engine needs 14 or later, and"
    warn "PostgreSQL $PG_BESIDE could not be installed beside it (is the internet reachable?)."
    warn "The engine will use it anyway and its setup wizard will say so. To retry:"
    warn "  sudo $SELF database"
}

# The URL this installer wrote, recognised by its shape. Anything else is an
# operator's own database and is never touched.
installer_url() {
    url=$(sed -n "s/^$DB_URL_VAR=//p" "$ENV_FILE" 2>/dev/null | tail -n 1)
    case "$url" in
        "postgres://$DB_USER:"*"@127.0.0.1:"*"/$DB_NAME") printf '%s' "$url" ;;
        *) return 1 ;;
    esac
}

url_connects() {
    psql "$1" -tAc 'SELECT 1' >/dev/null 2>&1
}

# Runs `database-when-ready` in the background, outside dpkg.
#
# Two things cannot happen inside a postinst. PostgreSQL may not have a cluster
# answering yet — packages installed with dpkg alone, or a cluster that is slow
# to start — and one that is too old cannot be replaced, because apt holds the
# lock. So the waiter is handed to systemd, outlives the apt run, and does
# both once it can. Without it the engine starts with no database and the
# setup wizard skips the administrator step.
wait_for_database_later() {
    [ -d /run/systemd/system ] && have systemd-run || return 1
    systemd-run --no-block --collect --quiet \
        --unit=hutech-engine-database \
        --description="HuTech Engine: connect the database once PostgreSQL is up" \
        "$SELF" database-when-ready >/dev/null 2>&1
}

ensure_database() {
    if ! postgres_ready && [ -n "${DPKG_MAINTSCRIPT_PACKAGE:-}" ]; then
        if wait_for_database_later; then
            say "PostgreSQL is not up yet — the engine will connect to it as soon as it is"
            return 0
        fi
        warn "PostgreSQL is not answering, so the engine was left without a"
        warn "database. Start it and re-run: $SELF database"
        return 0
    fi

    if ! postgres_ready; then
        if ! install_postgres; then
            warn "no package manager I recognise, so PostgreSQL was not installed."
            warn "The engine will run without one: live data only, no history, no"
            warn "accounts and no audit trail. Install PostgreSQL 14 or later and"
            warn "re-run $0 database to change that."
            return 0
        fi
    fi

    if ! postgres_ready; then
        warn "PostgreSQL is installed but not answering, so the engine was left"
        warn "without a database. Start it and re-run: $0 database"
        return 0
    fi

    # Already wired up. Said out loud rather than silently skipped, because the
    # other reason this branch is taken is an operator who pointed the engine at
    # a database of their own and would not want it changed.
    #
    # Except for this installer's own URL once it stops working, which is what a
    # PostgreSQL removed and reinstalled under a kept /etc/hutech-engine looks
    # like: the role is gone from the new cluster and the engine can never
    # connect. That one is replaced. A database that is still there keeps its
    # data, because only the role's password is reset below.
    if grep -q "^$DB_URL_VAR=" "$ENV_FILE" 2>/dev/null; then
        if url=$(installer_url) && ! url_connects "$url"; then
            sed -i "/^$DB_URL_VAR=/d" "$ENV_FILE"
            say "the engine's database login no longer works — setting it up again"
        else
            say "the engine already has a database configured — leaving it alone"
            return 0
        fi
    fi

    # Too old for the migrations. Inside dpkg nothing can be installed — apt
    # holds the lock — so that is handed to the waiter, which runs once the apt
    # run has finished.
    if too_old; then
        if [ -n "${DPKG_MAINTSCRIPT_PACKAGE:-}" ] && wait_for_database_later; then
            say "this machine's PostgreSQL is older than 14 — PostgreSQL $PG_BESIDE will be"
            say "installed beside it as soon as this apt run has finished"
            return 0
        fi
        if install_postgres_beside && pick_cluster && ! too_old; then
            say "PostgreSQL $PG_BESIDE is running beside the old one, on port $PG_PORT"
        else
            warn_if_too_old
        fi
    fi

    port=$PG_PORT

    if [ "$(printf "SELECT 1 FROM pg_roles WHERE rolname = '%s'" "$DB_USER" | as_postgres)" = "1" ]; then
        # The role is here but this machine has no URL for it — a reinstall over
        # a state directory that was kept, most likely. The password cannot be
        # read back out of PostgreSQL, so it is replaced rather than guessed.
        password=$(generate_password)
        printf "ALTER ROLE %s WITH LOGIN PASSWORD '%s'" "$DB_USER" "$password" | as_postgres >/dev/null
        say "reset the $DB_USER database password"
    else
        password=$(generate_password)
        printf "CREATE ROLE %s WITH LOGIN PASSWORD '%s'" "$DB_USER" "$password" | as_postgres >/dev/null
        say "created the $DB_USER database role"
    fi

    if [ "$(printf "SELECT 1 FROM pg_database WHERE datname = '%s'" "$DB_NAME" | as_postgres)" != "1" ]; then
        printf 'CREATE DATABASE %s OWNER %s' "$DB_NAME" "$DB_USER" | as_postgres >/dev/null
        say "created the $DB_NAME database"
    fi

    # Proved, then written. Nothing below this point runs on a connection the
    # engine could not have made itself.
    if ! engine_can_connect "$password" "$port"; then
        allow_password_auth || true
    fi

    if ! engine_can_connect "$password" "$port"; then
        warn "the $DB_NAME database exists, but the engine cannot authenticate to"
        warn "it — this machine's pg_hba.conf refuses a loopback password. Nothing"
        warn "was written to engine.toml, so the engine will start without a"
        warn "database rather than with one it cannot reach. Allow the engine in"
        warn "pg_hba.conf and re-run: $0 database"
        return 0
    fi

    # The URL goes in the environment file, not in engine.toml, so the password
    # lives in the one file that is already root-owned and group-readable and
    # never in the one an engineer opens to add a connector.
    printf '%s=postgres://%s:%s@127.0.0.1:%s/%s\n' \
        "$DB_URL_VAR" "$DB_USER" "$password" "$port" "$DB_NAME" >> "$ENV_FILE"
    chmod 0640 "$ENV_FILE"

    if ! grep -q '^\[database\]' "$CONF"; then
        # Appending a table header is safe wherever the file ends: a new `[...]`
        # closes whatever table came before it.
        cat >> "$CONF" <<EOF

# Added by the installer. The URL itself, password and all, is in
# $ENV_FILE.
[database]
url = "env:$DB_URL_VAR"
EOF
    fi

    say "PostgreSQL ready on port $port"
}

# The database step on its own, from an operator or from the waiter: the same
# as above, then a restart when the URL changed, because the engine reads it
# only at startup. Left out of `all`, which restarts the service anyway.
connect_database() {
    before=$(grep "^$DB_URL_VAR=" "$ENV_FILE" 2>/dev/null || true)
    ensure_database
    after=$(grep "^$DB_URL_VAR=" "$ENV_FILE" 2>/dev/null || true)

    if [ -n "$after" ] && [ "$after" != "$before" ] && [ -d /run/systemd/system ]; then
        if systemctl try-restart hutech-engine.service 2>/dev/null; then
            say "restarted the engine so it uses the database"
        fi
    fi
}

# What the waiter runs: up to ten minutes for PostgreSQL, then the database step.
database_when_ready() {
    tries=0
    while ! postgres_ready; do
        tries=$((tries + 1))
        if [ "$tries" -ge 120 ]; then
            warn "PostgreSQL did not answer within ten minutes, so the engine is"
            warn "still without a database. Start it and re-run: $SELF database"
            return 0
        fi
        sleep 5
    done
    connect_database
}

# ---------------------------------------------------------------------------
# The service
# ---------------------------------------------------------------------------

enable_service() {
    # `/run/systemd/system` is the test for systemd *running*, not merely
    # installed, and it is the difference between a package that installs and
    # one that leaves dpkg half-configured.
    #
    # `command -v systemctl` is not enough: in a container, a chroot or a golden
    # image being baked, systemctl is present and every call to it fails with
    # "System has not been booted with systemd as init system". Under `set -e`
    # that aborts the postinst, dpkg records the package as broken, and apt then
    # refuses to do anything else until somebody works out why.
    if [ ! -d /run/systemd/system ]; then
        warn "systemd is not running here, so the service was installed but not started."
        warn "On a normal boot it starts by itself. To start it now:"
        warn "  systemctl enable --now hutech-engine"
        return 0
    fi

    systemctl daemon-reload || true
    systemctl enable hutech-engine.service >/dev/null 2>&1 || true

    # The .deb also ships the watcher that installs updates staged by the
    # console. The tarball does not, so its presence is the test. `enable --now`
    # leaves an already-running watcher alone, which matters on an upgrade that
    # is itself being run by it.
    if [ -f /lib/systemd/system/hutech-engine-updater.path ]; then
        systemctl enable --now hutech-engine-updater.path >/dev/null 2>&1 || true
    fi

    # `restart` rather than `start`, because this same path runs on an upgrade
    # and a running engine would otherwise keep serving the old binary.
    #
    # A failure to start is reported, not fatal. The engine refusing to boot is
    # something the operator has to see, but it is not a reason for dpkg to mark
    # the package broken and block every later apt run.
    if ! systemctl restart hutech-engine.service; then
        warn "the engine did not start. What it said:"
        journalctl -u hutech-engine.service -n 20 --no-pager >&2 2>/dev/null || true
    fi
}

case "${1:-all}" in
    user) ensure_user ;;
    config) ensure_dirs; ensure_config; ensure_env_file ;;
    database) connect_database ;;
    database-when-ready) database_when_ready ;;
    service) enable_service ;;
    all)
        ensure_user
        ensure_dirs
        ensure_config
        ensure_env_file
        ensure_database
        enable_service
        ;;
    *)
        warn "usage: $0 [all|user|config|database|service]"
        exit 2
        ;;
esac
